package com.qsp.SpringDemo.ExceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionHandlingPlace {
	
	@ExceptionHandler(IdNotFoundException.class)
	public ResponseEntity<Object> entity(IdNotFoundException id)
	{
		return new ResponseEntity<Object>(id.getMessage(),HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(PasswordInvalidException.class)
	public ResponseEntity<Object> entity(PasswordInvalidException p)
	{
		return new ResponseEntity<Object>(p.getMessage(),HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(EmailNotValidException.class)
	public ResponseEntity<Object> entity(EmailNotValidException e)
	{
		return new ResponseEntity<Object>(e.getMessage(),HttpStatus.BAD_REQUEST);
	}


}
