package com.qsp.SpringDemo.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "EMPLOYEE")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Employee_Id")
	private int employeeId;
	@Column(name = "Employee_Name")
	private String employeeName;
	@Column(name = "Employee_Email")
	private String employeeEmail;
	@Column(name = "Employee_Salary")
	private String employeeSalary;
	@Column(name = "Employee_Department")
	private String employeeDepartment;
	@Column(name = "Employee_Password")
	private String employeePassword;
	

}
