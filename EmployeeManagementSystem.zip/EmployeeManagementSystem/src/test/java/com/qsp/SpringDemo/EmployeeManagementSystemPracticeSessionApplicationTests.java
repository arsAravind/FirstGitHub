package com.qsp.SpringDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemPracticeSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
